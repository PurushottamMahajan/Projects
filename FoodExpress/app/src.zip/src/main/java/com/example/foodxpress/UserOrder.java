package com.example.foodxpress;

public class UserOrder {
    String Name;
    String PhoneNumber;

//    public UserOrder(String name, String phoneNumber, String time) {
//        Name = name;
//        PhoneNumber = phoneNumber;
//        Time = time;
//    }

    String Time;

    public String getName() {
        return Name;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public String getTime() {
        return Time;
    }
}
